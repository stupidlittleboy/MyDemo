package mdtest.amarsoft.com.webviewjavascript;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

import cn.pedant.SafeWebViewBridge.InjectedChromeClient;


public class JavaJsBridgeActivity extends AppCompatActivity {

    public TextView tvBridgeMsg;
    private Button btnBridgeOK;
    private WebView wvBridge;

    private Handler hander = new Handler(){
        @Override
        public void handleMessage(Message msg) {

            switch (msg.what) {
                case 0:
                    tvBridgeMsg.setText("已接受数据");
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java_js_bridge);

        init();

        btnBridgeOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    private void init () {
        tvBridgeMsg = (TextView) findViewById(R.id.tv_bridge_msg);
        btnBridgeOK = (Button) findViewById(R.id.btn_bridge_ok);
        wvBridge = (WebView) findViewById(R.id.wv_bridge);

        WebSettings webSettings = wvBridge.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDefaultTextEncodingName("UTF-8");
        wvBridge.setWebChromeClient(
                new InjectedChromeClient("HostApp", (new HostJsScope(new JavaJsBridgeActivity())).getClass())
        );
        wvBridge.loadUrl("file:///android_asset/as.html");
//        String body = readHtmlData("as.html");
//        wvBridge.loadDataWithBaseURL("file:///android_asset/as.html", body, "text/html", "utf-8", "file:///android_asset/as.html");
    }

    private String getHtmlData (String fileName) {


        return null;
    }

    private String readHtmlData (String fileName) {
        String res = "";
        InputStream in = null;
        try {
            in = getResources().getAssets().open(fileName);
            int length = in.available();
            byte[] buffer = new byte[length];
            in.read(buffer);
            res = new String(buffer, "UTF-8");
            return res;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public void toast(String s) {
        Log.e("null", s + "hahahah");

        Message msg = new Message();
        msg.what = 0;
        hander.handleMessage(msg);
        Log.e("msg", msg.what+"");
//        tvBridgeMsg.setText(s);
    }

}
