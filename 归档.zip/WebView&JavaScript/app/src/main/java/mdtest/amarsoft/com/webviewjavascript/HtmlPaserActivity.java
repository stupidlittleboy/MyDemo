package mdtest.amarsoft.com.webviewjavascript;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;


public class HtmlPaserActivity extends AppCompatActivity {

    private TextView tvHtmlLoad;
    private Button btnHtmlLoad;
    private WebView wvLoadHtml;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_html_paser);

        init();

//        wvLoadHtml.loadDataWithBaseURL();

        btnHtmlLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }

    private void init () {
        tvHtmlLoad = (TextView) findViewById(R.id.tv_html_load);
        btnHtmlLoad = (Button) findViewById(R.id.btn_html_load);
        wvLoadHtml = (WebView) findViewById(R.id.wv_load_html);
    }

    private void setJs () {
        wvLoadHtml.setWebChromeClient(new WebChromeClient());
        wvLoadHtml.setWebViewClient(new MyWebViewClient());
        WebSettings ws = wvLoadHtml.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setAllowFileAccess(true);

    }

    /**
     * 用于js中调用Android端方法的接口
     */
    public class JsInteration {

        @JavascriptInterface
        public void toastMessage(String message, String json) {
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
        }

        @JavascriptInterface
        public void onSumResult(final String str) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //            Log.i(LOGTAG, "onSumResult result=" + result);
                    Toast.makeText(HtmlPaserActivity.this, "result = " + str, Toast.LENGTH_SHORT).show();
                    tvHtmlLoad.setText("result = " + str.toString());
                    JSONObject json = null;
                    try {
                        json = new JSONObject(str);
                        Log.e("json", json.toString());
                        Log.e("json1", json.get("section").toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

}
