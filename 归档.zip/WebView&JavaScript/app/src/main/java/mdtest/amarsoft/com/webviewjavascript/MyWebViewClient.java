package mdtest.amarsoft.com.webviewjavascript;

import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * 用于控制在触发webview中事件时，不会调用系统的浏览器显示
 *
 * Created by amarsoft on 2015/7/28.
 */
public class MyWebViewClient extends WebViewClient {

    // 用于加载新WebView,返回true代表着用完就消费掉
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        view.loadUrl(url);
        return true;
    }
}
