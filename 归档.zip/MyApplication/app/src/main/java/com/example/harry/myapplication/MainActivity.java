package com.example.harry.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.harry.myapplication.util.CommonUtil;

import java.io.InputStream;


public class MainActivity extends AppCompatActivity {

    private WebView wvJs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

       /* wvJs = (WebView) findViewById(R.id.wv_js);
        wvJs.getSettings().setJavaScriptEnabled(true);
        wvJs.setWebChromeClient(new WebChromeClient());
        wvJs.setWebViewClient(new WebViewClient());*/

        wvJs.loadUrl("http://www.example.com");
    }

    private void init() {
        wvJs = (WebView) findViewById(R.id.wv_js);
        wvJs.setWebChromeClient(new WebChromeClient());
        WebSettings ws = wvJs.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setDefaultTextEncodingName("UTF-8");
        wvJs.setWebViewClient(new WebViewClient());
        wvJs.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectScriptFile(view);

                view.loadUrl("javascript:setTimeout(test(), 500)");

            }

            private void injectScriptFile(WebView webView) {

                InputStream inputStream = null;
                try {
                    /*inputStream = getAssets().open(scriptFile);
                    byte[] buffer = new byte[inputStream.available()];
                    inputStream.read(buffer);
                    inputStream.close();*/

                    String test = "'use strict';\n" +
                            "\n" +
                            "function test() {\n" +
                            "    alert(\"hello world!水电费哈萨克\");\n" +
                            "}";

                    String encoded = Base64.encodeToString(test.getBytes(), Base64.NO_WRAP);
                    Log.e("encoded", encoded);
                    webView.loadUrl("javascript:(function() {" +
                            "var parent = document.getElementsByTagName('head').item(0);" +
                            "var script = document.createElement('script');" +
                            "script.type = 'text/javascript';" +
                            "script.charset = 'utf-8';" +
                            // Tell the browser to BASE64-decode the string into your script !!!
                            "script.innerHTML = decodeURIComponent(escape(window.atob('" + encoded + "')));" +
                            "parent.appendChild(script)" +
                            "})()");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    private void testEncry () {
        String msg = "你是我的！";
        String s = CommonUtil.encrypt(msg, "111");
        Log.e("s", s);
        Log.e("ss", CommonUtil.decrypt(s, "111"));
    }

}
