package com.example.image.imagesave.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import org.apache.commons.codec1.binary.Base64;

import java.io.ByteArrayOutputStream;

/**
 * Created by harry on 15/8/14.
 */
public class ImgSaveUtil {

    /**
     * 读取图片信息，并将图片转为字符串格式的数据
     * @param bitmap
     * @return
     */
    public static String imgToString (Bitmap bitmap) {
        int size = bitmap.getWidth() * bitmap.getHeight() * 4;
        ByteArrayOutputStream bos = new ByteArrayOutputStream(size);
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
        byte[] bytes = bos.toByteArray();
        String imgStr = Base64.encodeBase64String(bytes);
        String encryImg = CommonUtil.encrypt(imgStr, "123456");
        return encryImg;
    }

    /**
     * 将字符串格式的数据转为Bitmap格式的数据（图片）
     * @param str
     * @return
     */
    public static Bitmap stringToBitmap (String str) {
        String decryImg = CommonUtil.decrypt(str, "123456");
        byte[] bytes = Base64.decodeBase64(decryImg);
        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        return bitmap;
    }

    /**
     * 向SharedPreferences中写入数据，存储
     * @param context
     * @param key
     * @param value
     */
    public static void writeSp (Context context, String name, String key, Bitmap value) {
        String imgStr = imgToString(value);
        SharedPreferences sp = context.getSharedPreferences(name, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(key, imgStr);
        editor.commit();
    }

    /**
     * 读取SharedPreferences中存储的数据，默认返回""
     * @param context
     * @param key
     * @return
     */
    public static Bitmap readSpBitmap (Context context, String name, String key) {
        SharedPreferences sp = context.getSharedPreferences(name, Context.MODE_PRIVATE);
        String str = sp.getString(key, "");
        Bitmap bitmap = null;
        if (!"".equals(str)) {
            Log.e("img", str);
            bitmap = stringToBitmap(str);
        }
        return bitmap;
    }

    /**
     * 清除名为key的SharedPreferences中存储的数据
     * @param context
     * @param key
     */
    public static void clearSp (Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(key, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.clear();
    }
}
