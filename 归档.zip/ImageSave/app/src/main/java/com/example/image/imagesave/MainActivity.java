package com.example.image.imagesave;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.image.imagesave.util.ImgSaveUtil;


public class MainActivity extends AppCompatActivity {

    private ImageView ivTest;
    private Button btnSaveimage;
    private Button btnClearimage;
    private Button btnReadimage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    private void init () {
        ivTest = (ImageView) findViewById(R.id.iv_test);
        btnSaveimage = (Button) findViewById(R.id.btn_saveimage);
        btnClearimage = (Button) findViewById(R.id.btn_clearimage);
        btnReadimage = (Button) findViewById(R.id.btn_readimage);
//        vvTest.setVideoPath();

        final Bitmap bitmap1 = BitmapFactory.decodeResource(getResources(), R.mipmap.girl);
        Bitmap bitmap = null;//ImageSaveUtil.stringToBitmap(ImageSaveUtil.imgToString(bitmap1));

        SharedPreferences sp1 = getSharedPreferences("imgStr", Context.MODE_PRIVATE);
        String girlStr = sp1.getString("girlStr", "");
        if (!"".equals(girlStr)) {
            bitmap = ImgSaveUtil.stringToBitmap(girlStr);
        } else {
            bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.high);
        }



        ivTest.setImageBitmap(bitmap);

        ivTest.getResources().toString();
        Log.e("s", ivTest.getId() + "");

        btnSaveimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*SharedPreferences sp = getSharedPreferences("imgStr", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("girlStr", ImgSaveUtil.imgToString(bitmap1));
                editor.commit();*/

                ImgSaveUtil.writeSp(MainActivity.this, "imgStr", "girlStr", bitmap1);
            }
        });

        btnReadimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap2 = ImgSaveUtil.readSpBitmap(MainActivity.this, "imgStr", "girlStr");
                if (bitmap2 == null) {
                    Toast.makeText(MainActivity.this, "sharedpreferences is null", Toast.LENGTH_SHORT).show();
                }
                ivTest.setImageBitmap(bitmap2);
            }
        });

        btnClearimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sp = getSharedPreferences("imgStr", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.clear();
                editor.commit();
            }
        });
    }

}
