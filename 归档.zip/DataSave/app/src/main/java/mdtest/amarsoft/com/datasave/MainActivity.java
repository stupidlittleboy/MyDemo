package mdtest.amarsoft.com.datasave;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btnMainShared;
    private Button btnMainSqlite;
    private Button btnMainFile;
    private Button btnMainNetwork;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

    }

    private void init() {

        btnMainShared = (Button) findViewById(R.id.btn_main_shared);
        btnMainSqlite = (Button) findViewById(R.id.btn_main_sqlite);
        btnMainFile = (Button) findViewById(R.id.btn_main_file);
        btnMainNetwork = (Button) findViewById(R.id.btn_main_network);

        btnMainShared.setOnClickListener(this);
        btnMainSqlite.setOnClickListener(this);
        btnMainFile.setOnClickListener(this);
        btnMainNetwork.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btn_main_shared:
                Intent shared = new Intent(MainActivity.this, SharedSaveActivity.class);
                startActivity(shared);
                break;

            case R.id.btn_main_sqlite:
                Intent sqlite = new Intent(MainActivity.this, SqliteSaveActivity.class);
                startActivity(sqlite);
                break;

            case R.id.btn_main_file:
                Intent file = new Intent(MainActivity.this, FileSaveActivity.class);
                startActivity(file);
                break;

            case R.id.btn_main_network:
                Intent network = new Intent(MainActivity.this, SharedSaveActivity.class);
                startActivity(network);
                break;
        }

    }
}
