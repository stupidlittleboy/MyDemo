package mdtest.amarsoft.com.datasave;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class FileSaveActivity extends AppCompatActivity {

    private EditText etFileUsername;
    private EditText etFilePassword;
    private Button btnFileOk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_save);

        init();

        btnFileOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etFileUsername.getText().toString();
                String password = etFilePassword.getText().toString();
                fileSave(username + ":" + password);
                Toast.makeText(FileSaveActivity.this, "文件保存成功", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void init () {
        etFileUsername = (EditText) findViewById(R.id.et_file_username);
        etFilePassword = (EditText) findViewById(R.id.et_file_password);
        btnFileOk = (Button) findViewById(R.id.btn_file_ok);

        String str = fileRead();
        if (str == null || "".equals(str)) {
            etFileUsername.setText(str);
            Log.e("file_data", str+"");
        }
    }

    //文件存储
    private void fileSave (String content) {
        FileOutputStream fos = null;
        try {
            fos = openFileOutput("user.txt", MODE_APPEND);
            fos.write(content.getBytes());
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //文件读取
    private String fileRead () {
        FileInputStream fis = null;
        try {
            fis = openFileInput("user.txt");
            byte[] b = new byte[fis.available()];
            fis.read(b);
            return new String(b);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return null;
    }

}
