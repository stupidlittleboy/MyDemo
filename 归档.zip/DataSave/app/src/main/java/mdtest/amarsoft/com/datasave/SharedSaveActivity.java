package mdtest.amarsoft.com.datasave;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;


public class SharedSaveActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etPassword;
    private CheckBox cbRemember;
    private Button btnSharedOk;
    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_save);

        init();

        btnSharedOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();
                SharedPreferences.Editor edit = sp.edit();
                if (cbRemember.isChecked()) {
                    Toast.makeText(SharedSaveActivity.this, "记住了密码", Toast.LENGTH_SHORT).show();
                    edit.putString("username", username);
                    edit.putString("password", password);
                    edit.putBoolean("remember", true);
                    edit.commit();
                } else {
                    Toast.makeText(SharedSaveActivity.this, "放弃记住密码", Toast.LENGTH_SHORT).show();
                    edit.clear();
                    edit.commit();
                }
            }
        });
    }

    private void init() {
        etUsername = (EditText) findViewById(R.id.et_username);
        etPassword = (EditText) findViewById(R.id.et_password);
        cbRemember = (CheckBox) findViewById(R.id.cb_remember);
        btnSharedOk = (Button) findViewById(R.id.btn_shared_ok);
        sp = getSharedPreferences("zixin", MODE_PRIVATE);
        etUsername.setText(sp.getString("username", null));
        etPassword.setText(sp.getString("password", null));
        cbRemember.setChecked(sp.getBoolean("remember", false));
    }
}
