package mdtest.amarsoft.com.datasave;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.litepal.crud.DataSupport;


public class SqliteSaveActivity extends ActionBarActivity {

    private EditText etSqliteUsername;
    private EditText etSqlitePassword;
    private Button btnSqliteOk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqlite_save);

        init();

        btnSqliteOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etSqliteUsername.getText().toString();
                String password = etSqlitePassword.getText().toString();
                User user = new User();
                user.setUsername(username);
                user.setPassword(password);
                if (user.save()) {
                    Toast.makeText(SqliteSaveActivity.this, "存储成功", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SqliteSaveActivity.this, "存储失败", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void init () {
        etSqliteUsername = (EditText) findViewById(R.id.et_sqlite_username);
        etSqlitePassword = (EditText) findViewById(R.id.et_sqlite_password);
        btnSqliteOk = (Button) findViewById(R.id.btn_sqlite_ok);

        User users = DataSupport.findFirst(User.class);
        etSqliteUsername.setText(users.getUsername());
        etSqlitePassword.setText(users.getPassword());
    }

}
