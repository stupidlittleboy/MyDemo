package mdtest.amarsoft.com.clientsocketio;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebSettings;
import android.webkit.WebView;

import cn.pedant.SafeWebViewBridge.InjectedChromeClient;


public class WebViewActivity extends AppCompatActivity {

    private WebView wvTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        init();
    }

    private void init () {
        wvTest = (WebView) findViewById(R.id.wv_test);
        WebSettings webSettings = wvTest.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDefaultTextEncodingName("UTF-8");
        wvTest.setWebChromeClient(
                new InjectedChromeClient("HostApp", HostJsScope.class)
        );
        wvTest.loadUrl("file:///android_asset/as.html");
    }

}
