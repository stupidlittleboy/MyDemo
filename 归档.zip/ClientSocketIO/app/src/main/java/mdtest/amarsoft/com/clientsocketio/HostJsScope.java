package mdtest.amarsoft.com.clientsocketio;

import android.util.Log;
import android.webkit.WebView;

import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import java.net.URISyntaxException;


/**
 * Created by harry on 15/8/12.
 */
public class HostJsScope {
    public static Socket mSocket;
    private static void init() {
        try {
            mSocket = IO.socket("http://192.168.3.167:9092/");
            //            mSocket = IO.socket("http://192.168.1.5:9092/");
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }


    //创建socket连接

    public static void login(WebView webView, String str) {
        socketConn();
        if (mSocket.connected()) {
            mSocket.emit("login", str);
            mSocket.on("login", onLogin);
            mSocket.hasListeners("login");
        }

    }

    //连接到Server
    private static void socketConn() {
        init();
        mSocket.on(Socket.EVENT_CONNECT_ERROR, onConnectError);
        mSocket.on(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
        mSocket.connect();
    }

    private static Emitter.Listener onLogin = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            String s = (String) args[0];
            /*if (!"".equals(s) || s != null) {
                Log.e("server data : ", s);
                Message msg = new Message();
                msg.what = 0;
                handler.sendMessage(msg);
            }*/

        }
    };

    private static Emitter.Listener onConnectError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.e("commit", "failed to connected");
        }
    };
}
