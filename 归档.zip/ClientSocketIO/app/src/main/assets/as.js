function sayHello() {
        alert("Hello")
    }

    function alertMessage(message) {
        alert(message)
    }

var json = {"section":
{
        "title":"circle",
        "signing":[
            {
                "id":"1234",
                "name":"安硕圈"
            },
            {
                "id":"1235",
                "name":"海事圈"
            }
            ]
        }
};

var json1 = {
    "id":"139234242",
    "name":"你好吗？"
};

var s = "我是张三";
var ss = JSON.stringify(json1);
    function toastMessage(message) {
        window.HostApp.toastMessage(ss)
    }

    function sumToJava(number1, number2){
       window.control.onSumResult(ss)
    }

    function login() {
        window.HostApp.login(ss)
    }