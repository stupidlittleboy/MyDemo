package com.netty.server;

import java.util.ArrayList;
import java.util.List;

import com.corundumstudio.socketio.AckRequest;
import com.corundumstudio.socketio.Configuration;
import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.SocketIOServer;
import com.corundumstudio.socketio.listener.ConnectListener;
import com.corundumstudio.socketio.listener.DataListener;

public class ServerSocketIOForAndroid {

	public static void main(String[] args) {
		/**
		 * 创建Socket，并设置监听端口
		 */
		Configuration config = new Configuration();
		config.setHostname("192.168.3.225");
		//设置主机名
//		config.setHostname("localhost");
		//设置监听端口
		config.setPort(9092);
		/*config.setUpgradeTimeout(10000000);
        config.setPingTimeout(10000000);
        config.setPingInterval(10000000);*/
		final SocketIOServer server = new SocketIOServer(config);

		/**
		 * 添加连接监听事件，监听是否与客户端连接到服务器
		 */
		server.addConnectListener(new ConnectListener() {
			@Override
			public void onConnect(SocketIOClient client) {
				// 判断是否有客户端连接
				if (client != null) {
					System.out.println("链接成功。。。");
				} else {
					System.err.println("并没有人链接上。。。");
				}
				System.err.println(client.getSessionId().toString());
			}
		});

		/**
		 * 添加监听事件，监听客户端的事件
		 * 1.第一个参数eventName需要与客户端的事件要一致
		 * 2.第二个参数eventClase是传输的数据类型
		 * 3.第三个参数listener是用于接收客户端传的数据，数据类型需要与eventClass一致
		 */
		server.addEventListener("login", String.class, new DataListener<String>() {
			@Override
			public void onData(SocketIOClient client, String data,
					AckRequest ackSender) throws Exception {
				// TODO Auto-generated method stub
				System.err.println("接收到客户端的信息为：" + data);
				//向客户端发送消息
				List<String> list = new ArrayList<String>();
				list.add("haode");
				//第一个参数必须与eventName一致，第二个参数data必须与eventClass一致
				client.sendEvent("login", list.toString());
			}
		});
		//启动服务
		server.start();
	}
}