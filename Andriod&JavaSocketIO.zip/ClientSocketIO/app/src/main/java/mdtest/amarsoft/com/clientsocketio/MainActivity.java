package mdtest.amarsoft.com.clientsocketio;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.gc.materialdesign.views.ButtonRectangle;
import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends Activity {

    private ButtonRectangle btnSend;
    private TextView tvMessage;
    private EditText etMessage;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    Toast.makeText(MainActivity.this, "接收到了服务端的消息", Toast.LENGTH_SHORT).show();
            }
        }
    };

    //创建socket连接
    private Socket mSocket;
    {
        try {
            mSocket = IO.socket("http://192.168.3.225:9092/");
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        socketConn();
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = etMessage.getText().toString();
                List<String> list = new ArrayList<String>();
                list.add(message);
                if (mSocket.connected()) {
                    Toast.makeText(MainActivity.this, "链接成功。。。", Toast.LENGTH_SHORT).show();
                    //设置数据
                    mSocket.emit("login", list);
                    //连接服务
                    mSocket.on("login", onLogin);
                } else {
                    Toast.makeText(MainActivity.this, "链接失败。。。", Toast.LENGTH_SHORT).show();
                }
            }
        });
        mSocket.on("login", onLogin);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mSocket.off("login", onLogin);

        //取消连接Server
        mSocket.disconnect();
        mSocket.off(Socket.EVENT_CONNECT_ERROR, onConnectError);
        mSocket.off(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
    }

    //初始化控件信息
    private void init() {
        btnSend = (ButtonRectangle) findViewById(R.id.btn_send);
        tvMessage = (TextView) findViewById(R.id.tv_message);
        etMessage = (EditText) findViewById(R.id.et_message);
    }

    //连接到Server
    private void socketConn() {
        mSocket.on(Socket.EVENT_CONNECT_ERROR, onConnectError);
        mSocket.on(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
        mSocket.connect();
    }

    private Emitter.Listener onLogin = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            String s = (String) args[0];
            if (!"".equals(s) || s != null) {
                Log.e("server data : ", s);
                Message msg = new Message();
                msg.what = 0;
                handler.sendMessage(msg);
            }
        }
    };

    private Emitter.Listener onConnectError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(),
                            "Failed to connected...", Toast.LENGTH_LONG).show();
                }
            });
        }
    };

}
