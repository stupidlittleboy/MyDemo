package mdtest.amarsoft.com.webviewjavascript;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {

    private TextView tvJs;
    private Button btnJs;
    private WebView wvJs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        wvJs.loadUrl("file:///android_asset/as.html");

        btnJs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testMethod(wvJs);
            }
        });
    }

    private void init() {
        tvJs = (TextView) findViewById(R.id.tv_javascript);
        btnJs = (Button) findViewById(R.id.btn_javascript);
        wvJs = (WebView) findViewById(R.id.wv_javascript);

        setJavaScript();
    }

    public void setJavaScript() {
        //表示不支持js，如果想让java和js交互或者本身希望js完成一定的功能请把false改为true。
        wvJs.getSettings().setJavaScriptEnabled(true);

        //用于Js中调用JsInteration中的方法
        wvJs.addJavascriptInterface(new JsInteration(), "control");

        // 启用WebView访问文件数据
        wvJs.getSettings().setAllowFileAccess(true);

        //WebChromeClient主要辅助WebView处理Javascript的对话框、网站图标、网站title、加载进度等
        wvJs.setWebChromeClient(new WebChromeClient());

        //WebViewClient主要为WebView处理各种通知、请求事件。setWebViewClient（）该方法作用于点击链接
        // 时调用，点击跳转时，加载新的webview资源，并可以在加载前后添加操作，比如添加缓冲对话框，该
        // 方法的作用使得点击链接的响应在WebView内执行，而不是手机浏览器
        wvJs.setWebViewClient(new MyWebViewClient());

        /*//设置是否支持缩放，我这里为false，默认为true
        wvJs.getSettings().setSupportZoom(true);
        //设置是否显示缩放工具，默认为false
        wvJs.getSettings().setBuiltInZoomControls(true);
        // 设置缩放比例
        wvJs.setInitialScale(35);

        //一般很少会用到这个，用WebView组件显示普通网页时一般会出现横向滚动条，这样会导致页面查看起来非常不方便。LayoutAlgorithm是一个枚举，用来控制html的布局，总共有三种类型：
        //NORMAL：正常显示，没有渲染变化。
        //SINGLE_COLUMN：把所有内容放到WebView组件等宽的一列中。
        //NARROW_COLUMNS：可能的话，使所有列的宽度不超过屏幕宽度。
        wvJs.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);

        //设置默认的字体大小，默认为16，有效值区间在1-72之间
        wvJs.getSettings().setDefaultFontSize(16);

        //WebView显示html文件时，若要达到和PC上浏览器显示的效果完全一样，只需对WebView做一下设置即可：
        //适应全屏
        //39 适应竖屏
        //57 适应横屏
        wvJs.setInitialScale(39);

        //几种加速WebView加载的方法，提高渲染的优先级
        //把图片加载放在最后来加载渲染
        wvJs.getSettings().setBlockNetworkImage(true);

        // 将图片调整到适合WebView大小，设置该属性可通过双击或手指移动实现缩放
        wvJs.getSettings().setUseWideViewPort(true);

        // 支持多窗口
        wvJs.getSettings().supportMultipleWindows();

        // 设置自动加载图片
        wvJs.getSettings().setLoadsImagesAutomatically(true);

        // 如果需要用户输入账号密码，必须设置支持手势焦点
        wvJs.requestFocusFromTouch();

        // 取消滚动条
        wvJs.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);

        // 设置缓存模式
        wvJs.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        // 启用缓存
        wvJs.getSettings().setAppCacheEnabled(true);*/

    }

    //测试在Android端调用js中的方法
    private void testMethod(WebView webView) {
        String call;
//        call = "javascript:sayHello()";
//        call = "javascript:alertMessage(\"" + "content" + "\")";
//        call = "javascript:toastMessage(\"" + "content" + "\")";
        call = "javascript:sumToJava(1,2)";
        webView.loadUrl(call);
    }

    /**
     * 用于js中调用Android端方法的接口
     */
    public class JsInteration {

        @JavascriptInterface
        public void toastMessage(String message, String json) {
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
        }

        @JavascriptInterface
        public void onSumResult(final String str) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //            Log.i(LOGTAG, "onSumResult result=" + result);
                    Toast.makeText(MainActivity.this, "result = " + str, Toast.LENGTH_SHORT).show();
                    tvJs.setText("result = " + str.toString());
                    JSONObject json = null;
                    try {
                        json = new JSONObject(str);
                        Log.e("json", json.toString());
                        Log.e("json1", json.get("section").toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    //WebView的返回需要重写Activity的onKeyDown方法，使得回退返回至上一级，如果不重写，将会完全退出
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && wvJs.canGoBack())
        {
            wvJs.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
