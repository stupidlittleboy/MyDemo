function sayHello() {
        alert("Hello")
    }

    function alertMessage(message) {
        alert(message)
    }

var json = {"section":
{
        "title":"circle",
        "signing":[
            {
                "id":"1234",
                "name":"安硕圈"
            },
            {
                "id":"1235",
                "name":"海事圈"
            }
            ]
        }
};

var s = "我是张三";
var ss = JSON.stringify(json);
    function toastMessage(message) {
        window.control.toastMessage(message)
    }

    function sumToJava(number1, number2){
       window.control.onSumResult(ss)
    }